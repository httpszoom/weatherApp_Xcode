import Cocoa
import AVFoundation


let apiKey = "9d5002b55b3fdc06be8976d89577e02c"

let data: Data? = """
    {"coord":{"lon":2.3488,"lat":48.8534},"weather":[{"id":800,"main":"Clear","description":"clear sky","icon":"01n"}],"base":"stations","main":{"temp":280.69,"feels_like":278.37,"temp_min":279.26,"temp_max":282.04,"pressure":1021,"humidity":70},"visibility":10000,"wind":{"speed":1.03,"deg":190},"clouds":{"all":0},"dt":1616715584,"sys":{"type":1,"id":6550,"country":"FR","sunrise":1616737238,"sunset":1616782300},"timezone":3600,"id":2988507,"name":"Paris","cod":200}
""".data(using: .utf8)

struct Weather: Codable {
    var temp: Double?
    var humidity: Double?
}

struct WeatherMain: Codable {
    let main: Weather
}

func decodeJSONData(JSONData: Data) {
    do{
        let weatherData = try? JSONDecoder().decode(WeatherMain.self, from: JSONData)
        if let weatherData = weatherData{
            let weather = weatherData.main
            print(weather.temp!)
            print(weather.humidity!)
        }
    }
}

func pullJSONData(url: URL?, forecast: Bool){
    let task = URLSession.shared.dataTask(with: url!) { data, response, error in
        if let error = error {
            print("Error : \(error.localizedDescription)" )
        }
    
    guard let response = response as? HTTPURLResponse, response.statusCode == 200
        else {
            print("Error: HTTP Response Code Error")
            return
        }
    
    guard let data = data else {
        print("Erreur : aucune réponse")
        return
    }
    
    if (!forecast){
        decodeJSONData(JSONData: data)
    } else {
        
        }
        
    }
    task.resume()
}



let city: String = "belfort"
let url = URL(string: "http://api.openweathermap.org/data/2.5/weather?q=\(city)&appid=\(apiKey)&units=impeial")
 
pullJSONData(url: url, forecast: false)
